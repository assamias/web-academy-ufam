enum TipoErroApiEnum {
    INTERNO = "Erro interno da aplicação",
    RESTRICAO = "Erro de restrição de dado",
    NAO_ENCONTRADO = "Erro de registro não encontrado",
    VALIDACAO = "Erro de validação de dado"
}

export { TipoErroApiEnum };
